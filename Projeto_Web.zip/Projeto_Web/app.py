from flask import Flask, render_template, request, redirect
import json
import os

app = Flask(__name__)
ARQUIVO_TAREFAS = "tarefas.json"

# Função para carregar as tarefas do arquivo JSON para a memória do Python
def carregar_tarefas():
    if os.path.exists(ARQUIVO_TAREFAS):
        try:
            with open(ARQUIVO_TAREFAS, 'r', encoding='utf-8') as arquivo:
                return json.load(arquivo)
        except json.JSONDecodeError:
            # Se o arquivo estiver vazio ou corrompido, evita quebrar e retorna lista vazia
            return []
    return []

# Função para salvar a lista de tarefas atualizada de volta no arquivo JSON
def salvar_tarefas(lista):
    with open(ARQUIVO_TAREFAS, 'w', encoding='utf-8') as arquivo:
        json.dump(lista, arquivo, indent=4, ensure_ascii=False)

# ROTA PRINCIPAL: Carrega as tarefas e renderiza a página visual
@app.route('/')
def home():
    minhas_tarefas = carregar_tarefas()
    return render_template('index.html', tarefas=minhas_tarefas)

# ROTA ADICIONAR: Recebe os dados do formulário e cria uma nova tarefa
@app.route('/adicionar', methods=['POST'])
def adicionar():
    nome_digitado = request.form.get('nome_da_tarefa')
    descricao_digitada = request.form.get('descricao_da_tarefa', '') 
    
    if nome_digitado:
        tarefas = carregar_tarefas()
        
        nova_tarefa = {
            "nome": nome_digitado, 
            "descricao": descricao_digitada, 
            "concluida": False
        }
        
        tarefas.append(nova_tarefa)
        salvar_tarefas(tarefas)
        
    return redirect('/')

# ROTA EDITAR: Recebe o índice da tarefa e atualiza seu título e descrição
@app.route('/editar/<int:indice>', methods=['POST'])
def editar(indice):
    tarefas = carregar_tarefas()
    
    if 0 <= indice < len(tarefas):
        novo_nome = request.form.get('nome_da_tarefa')
        nova_descricao = request.form.get('descricao_da_tarefa', '')
        
        if novo_nome:
            tarefas[indice]["nome"] = novo_nome
            tarefas[indice]["descricao"] = nova_descricao
            salvar_tarefas(tarefas)
            
    return redirect('/')

# ROTA CONCLUIR: Altera o status da tarefa para concluída (True)
@app.route('/concluir/<int:indice>')
def concluir(indice):
    tarefas = carregar_tarefas()
    
    if 0 <= indice < len(tarefas):
        tarefas[indice]["concluida"] = True
        salvar_tarefas(tarefas)
        
    return redirect('/')

# ROTA REMOVER: Apaga a tarefa correspondente da lista
@app.route('/remover/<int:indice>')
def remover(indice):
    tarefas = carregar_tarefas()
    
    if 0 <= indice < len(tarefas):
        tarefas.pop(indice)
        salvar_tarefas(tarefas)
        
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)
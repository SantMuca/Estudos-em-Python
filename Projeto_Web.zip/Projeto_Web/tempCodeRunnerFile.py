from flask import Flask, render_template, request, redirect
import json
import os

app = Flask(__name__)
ARQUIVO_TAREFAS = "tarefas.json"

def carregar_tarefas():
    if os.path.exists(ARQUIVO_TAREFAS):
        try:
            with open(ARQUIVO_TAREFAS, 'r', encoding='utf-8') as arquivo:
                return json.load(arquivo)
        except json.JSONDecodeError:
            return []
    return []

# Função antiga de salvar, adaptada para receber a lista como parâmetro
def salvar_tarefas(lista):
    with open(ARQUIVO_TAREFAS, 'w', encoding='utf-8') as arquivo:
        json.dump(lista, arquivo, indent=4, ensure_ascii=False)

@app.route('/')
def home():
    minhas_tarefas = carregar_tarefas()
    return render_template('index.html', tarefas=minhas_tarefas)

# Avisa o Flask que esta rota só aceita receber dados de formulários
@app.route('/adicionar', methods=['POST'])
def adicionar():
    # 1. Puxa o que o usuário digitou no campo com name="nome_da_tarefa"
    nome_digitado = request.form.get('nome_da_tarefa')
    
    # Se o usuário digitou alguma coisa
    if nome_digitado:
        # 2. Carregamos a lista atual
        tarefas = carregar_tarefas()
        
        nova_tarefa = {"nome": nome_digitado, "concluida": False}
        
        tarefas.append(nova_tarefa)
        salvar_tarefas(tarefas)
        
    # 5. Redireciona o usuário de volta para a rota '/' (página principal) para ele ver a lista atualizada
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)